package com.example.hireme.util;

public class IT20245092_ReviewAdapter {
}
